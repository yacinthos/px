package com.libstore.cache.core;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.util.ErrorHandler;

import com.github.benmanes.caffeine.cache.Cache;
import com.libstore.cache.config.CacheConfig;
import com.libstore.cache.model.CacheableEntity;

import lombok.Data;

class CacheBuilderTest {
    Function<String, TestEntity> transformer = id -> new TestEntity(id);
    ErrorHandler errorHandler = mock(ErrorHandler.class);
    ThreadPoolTaskScheduler scheduler;
    private CacheBuilder cacheBuilder;

    @BeforeEach
    void setUp() {
        scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(1);
        scheduler.setThreadNamePrefix("builder-test-cache-refresh-");
        scheduler.setAwaitTerminationSeconds(60);
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        scheduler.setErrorHandler(errorHandler);
        scheduler.initialize();
        cacheBuilder = new CacheBuilder(new CaffeineCacheManager(), scheduler);
    }

    @AfterEach
    public void tearDown() {
        scheduler.shutdown();
    }

    @Test
    void shouldBuildAndInitializeCache() throws InterruptedException {

        Cache<String, TestEntity> cache = cacheBuilder.build(
                CacheConfig.of(
                        "testCache",
                        Duration.ofSeconds(5),
                        Duration.ofMinutes(1),
                        100),
                () -> Arrays.asList("test1", "test2", "test3"),
                transformer);

        Thread.sleep(2000);

        assertThat(cache).isNotNull();
        assertThat(cache.estimatedSize()).isEqualTo(3);
        assertThat(cache.asMap().values())
                .extracting(TestEntity::getId)
                .containsExactlyInAnyOrder("test1", "test2", "test3");
    }

    @Test
    void shouldRefreshCacheAutomatically() throws InterruptedException {
        // Given
        AtomicInteger counter = new AtomicInteger(0);
        List<String> initialData = Arrays.asList("initial1", "initial2");
        List<String> refreshedData = Arrays.asList("refreshed1", "refreshed2", "refreshed3");

        Cache<String, TestEntity> cache = cacheBuilder.build(
                CacheConfig.of("refreshTestCache",
                        Duration.ofMinutes(1),
                        Duration.ofSeconds(5),
                        100),
                () -> counter.getAndIncrement() == 0 ? initialData : refreshedData,
                transformer);
        Thread.sleep(1000);
        // Then - Initial state
        assertThat(cache.estimatedSize()).isEqualTo(2);
        assertThat(cache.asMap().values())
                .extracting(TestEntity::getId)
                .containsExactlyInAnyOrder("initial1", "initial2");

        // When - Wait for refresh
        Thread.sleep(5000);

        // Then - Refreshed state
        assertThat(cache.estimatedSize()).isEqualTo(3);
        assertThat(cache.asMap().values())
                .extracting(TestEntity::getId)
                .containsExactlyInAnyOrder("refreshed1", "refreshed2", "refreshed3");
    }

    @Test
    void shouldHandleExpiration() throws InterruptedException {
        // Given
        Cache<String, TestEntity> cache = cacheBuilder.build(
                CacheConfig.of("expirationTestCache",
                        Duration.ofSeconds(5),
                        Duration.ofMinutes(1),
                        100),
                () -> Collections.singletonList("test-data"),
                transformer);

        String cacheKey = new TestEntity("test-data").getCacheKey();
        Thread.sleep(1000);
        // Then - Initial state
        assertThat(cache.getIfPresent(cacheKey)).isNotNull();

        // When - Wait for expiration
        Thread.sleep(5000);

        // Then - After expiration
        assertThat(cache.getIfPresent(cacheKey)).isNull();
    }

    @Test
    void shouldRespectMaxSize() throws InterruptedException {
        // Given
        Cache<String, TestEntity> cache = cacheBuilder.build(
                CacheConfig.of("sizeTestCache",
                        Duration.ofMinutes(1),
                        Duration.ofMinutes(1),
                        2),
                () -> Arrays.asList("data1", "data2", "data3", "data4"),
                transformer);
        Thread.sleep(2500);
        // Then
        assertThat(cache.estimatedSize()).isLessThanOrEqualTo(2);
    }

    @Test
    void shouldHandleRefreshErrors() throws InterruptedException {

        cacheBuilder.build(
                CacheConfig.of("errorTestCache",
                        Duration.ofMinutes(1),
                        Duration.ofMinutes(1),
                        100),
                () -> {
                    throw new RuntimeException("Simulated error");
                },
                transformer);

        // When - Wait for expiration
        Thread.sleep(2500);

        ArgumentCaptor<Throwable> captor = ArgumentCaptor.forClass(Throwable.class);
        verify(errorHandler, atLeastOnce()).handleError(captor.capture());
        Throwable capturedException = captor.getValue();
        assertTrue(capturedException instanceof CacheLoadException);
        assertThat(capturedException.getMessage()).contains("Failed to refresh cache");

    }

    @Data
    static class TestEntity implements CacheableEntity<String> {
        private final String id;

        @Override
        public String getCacheKey() {
            return id;
        }
    }

}