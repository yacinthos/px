package com.libstore.cache.product.service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

import com.libstore.cache.product.client.ProductApiClient;
import com.libstore.cache.product.model.ProductDTO;
import com.libstore.cache.product.model.ProductReferentialData;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class ProductCacheServiceIntegrationTest {

    @Autowired
    private ProductCacheService productCacheService;

    @SpyBean
    private ProductApiClient productApiClient;

    @BeforeEach
    void setUp() {
        // Nettoyer l'état du cache avant chaque test
        productCacheService.invalidateAll();
    }

    @Test
    void shouldLoadAndRefreshCache() throws InterruptedException {
        // Given
        List<ProductReferentialData> initialProducts = createManyMockProducts(2);
        List<ProductReferentialData> updatedProducts = createManyMockProducts(5);

        when(productApiClient.fetchProducts())
                .thenReturn(initialProducts)
                .thenReturn(updatedProducts);

        // When - Attendre le refresh automatique
        Thread.sleep(2500); // Attendre plus que l'intervalle de refresh

        // When - Initial load
        Collection<ProductDTO> initialCache = productCacheService.getAll();
        // Then - Vérifier le chargement initial
        assertThat(initialCache)
                .hasSize(2)
                .extracting("name")
                .containsExactlyInAnyOrder("Product 0", "Product 1");

        // Vérifier que l'API a été appelée deux fois
        verify(productApiClient, times(2)).fetchProducts();
    }

    private List<ProductReferentialData> createManyMockProducts(int count) {
        return IntStream.range(0, count)
                .mapToObj(i -> ProductReferentialData.builder()
                        .externalId("PROD-" + i)
                        .name("Product " + i)
                        .description("Description " + i)
                        .price((double) i)
                        .build())
                .collect(Collectors.toList());
    }

}