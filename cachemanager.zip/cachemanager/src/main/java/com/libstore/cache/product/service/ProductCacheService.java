
package com.libstore.cache.product.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.libstore.cache.config.CacheConfig;
import com.libstore.cache.core.CacheBuilder;
import com.libstore.cache.core.service.AbstractCacheService;
import com.libstore.cache.product.client.ProductApiClient;
import com.libstore.cache.product.model.ProductDTO;
import com.libstore.cache.product.model.ProductReferentialData;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductCacheService extends AbstractCacheService<String, ProductDTO, ProductReferentialData> {

    public ProductCacheService(@Qualifier("productCacheConfig") CacheConfig cacheConfig, CacheBuilder cacheBuilder,
            ProductApiClient productApiClient) {
        super(cacheConfig, cacheBuilder, productApiClient::fetchProducts);
    }

    @Override
    protected ProductDTO transformToEntity(ProductReferentialData data) {
        return ProductDTO.builder()
                .id(data.getExternalId())
                .name(data.getName())
                .description(data.getDescription())
                .price(data.getPrice())
                .build();
    }
}