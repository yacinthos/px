package com.libstore.cache.core;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.function.Function;
import java.util.function.Supplier;

import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.scheduling.TaskScheduler;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.libstore.cache.config.CacheConfig;
import com.libstore.cache.model.CacheableEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CacheBuilder {
    private final CaffeineCacheManager cacheManager;
    private final Map<String, ScheduledFuture<?>> cacheRefreshTasks;
    private final TaskScheduler taskScheduler;

    public CacheBuilder(CaffeineCacheManager cacheManager, TaskScheduler taskScheduler) {
        this.cacheManager = cacheManager;
        this.cacheRefreshTasks = new ConcurrentHashMap<>();
        this.taskScheduler = taskScheduler;
    }

    /**
     * Creates and configures a new cache with automatic reload.
     *
     * @param <K>                Cache key type
     * @param <V>                Cache value type
     * @param <R>                Raw data type before transformation
     * @param cacheConfiguration Configuration for the cache to create
     * @param dataProvider       Provider for the data to be cached
     * @param dataTransformer    Transformer for raw data to cacheable entities
     * @return The configured cache
     */
    public <K, V extends CacheableEntity<K>, R> Cache<K, V> build(
            CacheConfig cacheConfiguration,
            Supplier<List<R>> dataProvider,
            Function<R, V> dataTransformer) {

        log.info("Initializing cache '{}' with TTL={}s, refresh={}s, maxSize={}",
                cacheConfiguration.getName(),
                cacheConfiguration.getTtl().toSeconds(),
                cacheConfiguration.getRefreshInterval().toSeconds(),
                cacheConfiguration.getMaxSize());

        cacheManager.registerCustomCache(cacheConfiguration.getName(), Caffeine.newBuilder()
                .expireAfterWrite(cacheConfiguration.getTtl())
                .recordStats()
                .maximumSize(cacheConfiguration.getMaxSize())
                .build());

        @SuppressWarnings("unchecked")
        Cache<K, V> cache = (Cache<K, V>) cacheManager.getCache(cacheConfiguration.getName()).getNativeCache();
        schedulePeriodicRefresh(cacheConfiguration,
                () -> refreshCache(cacheConfiguration.getName(), cache, dataProvider, dataTransformer));

        return cache;
    }

    private <K, V extends CacheableEntity<K>, R> void refreshCache(
            String cacheName,
            Cache<K, V> cache,
            Supplier<List<R>> dataProvider,
            Function<R, V> transformer) {

        log.info("Starting refresh for cache: {}", cacheName);
        try {
            List<R> freshData = dataProvider.get();
            cache.invalidateAll();
            freshData.stream()
                    .map(transformer)
                    .forEach(entity -> cache.put(entity.getCacheKey(), entity));
            log.info("Successfully refreshed cache '{}' with {} items", cacheName, cache.estimatedSize());
        } catch (Exception error) {
            String errorMessage = String.format("Failed to refresh cache '%s'", cacheName);
            log.error(errorMessage, error);
            throw new CacheLoadException(errorMessage, error);
        }
    }

    private void schedulePeriodicRefresh(CacheConfig config, Runnable refreshTask) {

        cancelExistingRefreshTask(config.getName());
        ScheduledFuture<?> newRefreshTask = taskScheduler.scheduleAtFixedRate(
                refreshTask,
                Instant.now(),
                config.getRefreshInterval());

        cacheRefreshTasks.put(config.getName(), newRefreshTask);
        log.info("Scheduled periodic refresh for cache '{}' every {} seconds",
                config.getName(),
                config.getRefreshInterval().toSeconds());
    }

    private void cancelExistingRefreshTask(String cacheName) {
        ScheduledFuture<?> existingTask = cacheRefreshTasks.get(cacheName);
        if (existingTask != null && !existingTask.isCancelled()) {
            existingTask.cancel(false);
        }
    }

}