package com.libstore.cache.product.client;

import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;

import org.springframework.stereotype.Component;

import com.libstore.cache.product.model.ProductReferentialData;

@Component
public class ProductApiClient {

    private final Random random = new Random();

    public List<ProductReferentialData> fetchProducts() {
        // Simuler un appel API
        return IntStream.range(0, 10)
                .mapToObj(i -> ProductReferentialData.builder()
                        .externalId("PROD-" + i)
                        .name("Product " + i)
                        .description("Description " + i)
                        .price(random.nextDouble() * 100)
                        .build())
                .toList();
    }
}