// AbstractCacheService.java
package com.libstore.cache.core.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import com.github.benmanes.caffeine.cache.Cache;
import com.libstore.cache.config.CacheConfig;
import com.libstore.cache.core.CacheBuilder;
import com.libstore.cache.model.CacheableEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class AbstractCacheService<K, V extends CacheableEntity<K>, R> {

    protected final Cache<K, V> cache;

    protected AbstractCacheService(
            CacheConfig cacheConfig,
            CacheBuilder cacheBuilder,
            Supplier<List<R>> dataProvider) {
        this.cache = cacheBuilder.build(
                cacheConfig,
                dataProvider,
                this::transformToEntity);
    }

    protected abstract V transformToEntity(R referentialData);

    public Optional<V> getByKey(K key) {
        return Optional.ofNullable(cache.getIfPresent(key));
    }

    public Collection<V> getAll() {
        return cache.asMap().values();
    }

    public long getCacheSize() {
        return cache.estimatedSize();
    }

    public void invalidateAll() {
        cache.invalidateAll();
    }
}