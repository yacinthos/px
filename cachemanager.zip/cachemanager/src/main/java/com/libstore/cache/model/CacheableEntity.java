package com.libstore.cache.model;

public interface CacheableEntity<K> {
    K getCacheKey();
}
