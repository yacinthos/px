package com.libstore.cache.product.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductReferentialData {
    String externalId;
    String name;
    String description;
    double price;
}