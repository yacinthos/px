package com.libstore.cache.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import com.libstore.cache.core.CacheBuilder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableCaching
@EnableScheduling
public class CacheConfiguration {

    @Bean
    public CaffeineCacheManager caffeineCacheManager() {
        return new CaffeineCacheManager();
    }

    @Bean
    public TaskScheduler taskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(10);
        scheduler.setThreadNamePrefix("cache-refresh-");
        scheduler.setAwaitTerminationSeconds(60);
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        scheduler.setErrorHandler(t -> log.error("Error in scheduled task", t));
        scheduler.initialize();
        return scheduler;
    }

    @Bean
    public CacheBuilder cacheBuilder(CaffeineCacheManager cacheManager, TaskScheduler taskScheduler) {
        return new CacheBuilder(cacheManager, taskScheduler);
    }

    @Bean
    @ConfigurationProperties(prefix = "cache.product")
    public CacheConfig productCacheConfig() {
        return CacheConfig.builder().build();
    }

}