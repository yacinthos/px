package com.libstore.cache.config;

import java.time.Duration;

import org.springframework.validation.annotation.Validated;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Validated
public class CacheConfig {
    private String name;
    private Duration ttl;
    private Duration refreshInterval;
    private long maxSize;

    public static CacheConfig of(String name, Duration ttl, Duration refreshInterval, long maxSize) {
        return CacheConfig.builder()
                .name(name)
                .ttl(ttl)
                .refreshInterval(refreshInterval)
                .maxSize(maxSize)
                .build();
    }
}
