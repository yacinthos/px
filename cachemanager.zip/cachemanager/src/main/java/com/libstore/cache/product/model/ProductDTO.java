package com.libstore.cache.product.model;

import com.libstore.cache.model.CacheableEntity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductDTO implements CacheableEntity<String> {
    String id;
    String name;
    String description;
    double price;

    @Override
    public String getCacheKey() {
        return id;
    }
}
