package com.libstore.cache.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Tier {
    String id;
    String type;
    String codeGroupe; // null si ce n'est pas un type 02 ou 04

    public Tier(String id, String type, String codeGroupe) {
        this.id = id;
        this.type = type;
        this.codeGroupe = codeGroupe;
    }
}

class TierHierarchyResult {
    Tier searchedTier;
    Tier parentLevel2;
    Tier root;

    public TierHierarchyResult(Tier searchedTier, Tier parentLevel2, Tier root) {
        this.searchedTier = searchedTier;
        this.parentLevel2 = parentLevel2;
        this.root = root;
    }

    public void display() {
        System.out.println("Searched Tier: " + (searchedTier != null ? searchedTier.id : "null"));
        System.out.println("Parent Level 2: " + (parentLevel2 != null ? parentLevel2.id : "null"));
        System.out.println("Root: " + (root != null ? root.id : "null"));
    }
}

public class TierHierarchy {

    // Méthode principale pour récupérer un tier et ses parents
    public static TierHierarchyResult findTierWithParents(String id, List<Tier> tiers) {
        // Index des tiers par leur ID pour un accès rapide, et stocker les tiers de
        // type 02 par code_groupe
        Map<String, Tier> tierById = new HashMap<>();
        Map<String, Tier> tierByCodeGroupe = new HashMap<>();
        Tier root = null;

        for (Tier tier : tiers) {
            tierById.put(tier.id, tier); // Indexer tous les tiers, y compris ceux de type 05
            if (tier.type.equals("01")) {
                root = tier; // Le seul tier de type 01 est la racine
            } else if (tier.type.equals("02")) {
                tierByCodeGroupe.put(tier.codeGroupe, tier); // Stocker les tiers de type 02 par code_groupe
            }
        }

        Tier searchedTier = tierById.get(id);
        if (searchedTier == null)
            return new TierHierarchyResult(null, null, null); // Tier introuvable

        // Si le tier est de type 05, il est indépendant, donc pas de parent
        if (searchedTier.type.equals("05")) {
            return new TierHierarchyResult(searchedTier, null, null);
        }

        // Initialisation des parents
        Tier parentLevel2 = null;

        // Récupérer les parents selon le type du tier recherché
        if (searchedTier.type.equals("04") && searchedTier.codeGroupe != null) {
            // Niveau 3 : On récupère le parent de type 02 via code_groupe
            parentLevel2 = tierByCodeGroupe.get(searchedTier.codeGroupe);
        } else if (searchedTier.type.equals("02") || searchedTier.type.equals("03")) {
            // Niveau 2 : Pas de parent de niveau 2 pour les types 02 ou 03, uniquement la
            // racine
        }

        return new TierHierarchyResult(searchedTier, parentLevel2, root);
    }

    public static void test() {
        // Exemple de liste de tiers
        List<Tier> tiers = Arrays.asList(
                new Tier("1", "01", null), // Racine
                new Tier("2", "02", "G1"), // Niveau 2
                new Tier("3", "03", null), // Niveau 2
                new Tier("4", "04", "G1"), // Niveau 3
                new Tier("5", "04", "G1"), // Niveau 3
                new Tier("6", "05", null) // Indépendant, niveau spécial
        );

        // Test de la méthode
        TierHierarchyResult result = findTierWithParents("4", tiers);
        result.display();
    }
}
